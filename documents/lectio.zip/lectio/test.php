<?php

require_once('base_controller.php');

// Fortæl browseren at vi ønsker at bruge æøå
header('Content-Type: text/html; charset=utf-8');

require_once('test/test_lectio.php');
require_once('test/test_users.php');


?>