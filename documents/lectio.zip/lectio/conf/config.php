<?php
    
    define('APP_ID', '387338711294423');
    define('APP_SECRET', '5866996ea32ae429604e68358fd72e62');
    
    // URLen som facebook giver os adgangs token via
    define('APP_REDIRECT_URL', 'http://skyen.iftek.dk/~jakob/lectio/auth.php');
    define('DB_PATH', 'db');
    
    // publish_stream: Adgang til at indsætte indhold i fb stream
    // offline_access: Adgang for evigt
    define('APP_PERMISSIONS', 'publish_stream,offline_access');

    if(APP_ID == '' || APP_SECRET == '' || APP_REDIRECT_URL == ''){
        header('Content-type: text/html; charset=utf-8');
        print('Husk du skal sætte app id, app secret og app url i conf/config.php');
        die();
    }
?>
