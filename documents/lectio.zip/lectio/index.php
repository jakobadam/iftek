<?php

require_once("settings.php");

?>
